export const themas = {
    colors:{
        primary:' 878af6',
        secundary:' #ffffff',
        lightGray:' #d7d8d7',
        gray:'white',
        bgScreen:' #f1f7fa',

    }

}