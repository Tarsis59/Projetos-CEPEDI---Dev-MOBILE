import React from 'react'
import {Text} from 'react-native'

export default function User(){
    return(<Text>
        User
    </Text>)
}